﻿Imports System.Management.Instrumentation

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '''' make the window green
        '''' Define the window to be 800x600
        '''

        Me.Width = 800
        Me.Height = 600
        ''Make it so that the window cant reszie
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        '''' Make the window appear in the middle of the screen
        '''[ Generate a maximize box to disable
        Me.StartPosition = FormStartPosition.CenterScreen
        MessageBox.Show("Welcome to Flames Co. Robotics TEST EAD System v0.00")

    End Sub
End Class
